console.log("Portfolio Amar aktif!");
